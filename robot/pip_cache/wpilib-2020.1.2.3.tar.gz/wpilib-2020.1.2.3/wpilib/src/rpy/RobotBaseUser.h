#pragma once

#include <frc/RobotBase.h>

namespace frc {

class RobotBaseUser : public RobotBase {
public:
  RobotBaseUser() : RobotBase() {}
  ~RobotBaseUser() {}
};

} // namespace frc
